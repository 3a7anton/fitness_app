part of 'home_bloc.dart';

@immutable
abstract class HomeEvent {}

class ReloadImageEvent extends HomeEvent {}
